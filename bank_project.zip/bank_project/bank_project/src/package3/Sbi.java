package package3;

import java.util.Scanner;

import package1.Account;
import package2.Rbi;

public class Sbi implements Rbi {
	double currentbal;
	double updatebal;
	double deposit;
	int open;
	Scanner sc=new Scanner(System.in);
	
	Account ac[];
	@Override
	public void createAccount() {
		System.out.println("how many account u want to open");
		open=sc.nextInt();
		ac=new Account[open];
		for(int i=0;i<ac.length;i++)
		{
		Account a=new Account();
		
		System.out.println("enter customer accno");
		int accno=(sc.nextInt());
		a.setAccNo(accno);
		System.out.println("enter customer name");
		String name=sc.next();
		a.setName(name);
		System.out.println("enter customer mobno");
		a.setMobNo(sc.next());
		System.out.println("enter customer adhno");
		a.setAdharNo(sc.next());
		System.out.println("enter customer gender");
		a.setGender(sc.next());
		System.out.println("enter customer age");
		a.setAge(sc.nextInt());
		System.out.println("u want to deposit atleast 500 to open acc");
		deposit=sc.nextDouble();
		while(deposit<500)
		{
			System.out.println("amount should be greater than 500");
			System.out.println("pay again");
			deposit=sc.nextDouble();
		}
		a.setBalance(deposit);
		System.out.println("u r account created successfully");
		ac[i]=a;
//		if(ac[i]!=null)
//		{			
//		for(int j=i;j>=0;j--)
//		{
//			System.out.println("in for..................");
//		//	if(ac[j]!=null){
//				System.out.println("In 1st if....."+accno+" "+ac[j].getAccNo());
//				if(accno==ac[j].getAccNo())
//				{
//					System.out.println("In 2nd if.....");
//					System.out.println("Acc. No already exist...");
//					System.out.println("Please Re-Enter customer accno");
//					accno=(sc.nextInt());
//					a.setAccNo(accno);
//					ac[i]=a;
//				}
//			}
//		}
		
		
		
		
		}

	}

	@Override
	public void displayAllDetails() {
		for(int i=0;i<ac.length;i++)
		{
		Account aa=ac[i];
		System.out.println("customer acc no  "+aa.getAccNo());
		System.out.println("customer name "+aa.getName());
		System.out.println("customer mobile no "+aa.getMobNo());
		System.out.println("customer aadhar no "+aa.getAdharNo());
		System.out.println("customer gender "+aa.getGender());
		System.out.println("customer age "+aa.getAge());
		System.out.println("customer balance "+aa.getBalance());
		System.out.println("\n");
		}
	}

	@Override
	public void depositeMoney() {
		System.out.println("how much money u want to deposit");
		deposit=sc.nextDouble();
	//	currentbal=a.getBalance();
		updatebal=currentbal+deposit;
	//	a.setBalance(updatebal);
		System.out.println("u r money successfully deposited");
	}

	@Override
	public void withdrawal() {
		System.out.println("how much money u want to withdraw");
		deposit=sc.nextDouble();
	//	currentbal=a.getBalance();
		updatebal=currentbal-deposit;
	//	a.setBalance(updatebal);
		System.out.println("u r money successfully withdraw");
	}

	@Override
	public void balanceCheck() {
		//System.out.println("u r balance"+a.getBalance());
		//System.out.println("update balance="+money);
	}

}
